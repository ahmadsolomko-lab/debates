import 'package:flutter/material.dart';

import 'screens/home_screen.dart';

void main() {
  runApp(const DebatesApp());
}

/// Робоча назва. Остаточну назву оберемо перед публікацією.
const String appTitle = 'Дебати';

/// Фірмові кольори (змінюються тут в одному місці).
class AppColors {
  static const Color background = Color(0xFF0E1116);
  static const Color surface = Color(0xFF171B22);
  static const Color surfaceHigh = Color(0xFF212733);
  static const Color accent = Color(0xFFFF6B35); // помаранчевий «арени»
  static const Color pro = Color(0xFF3DDC97); // ЗА
  static const Color con = Color(0xFFFF5470); // ПРОТИ
  static const Color textMuted = Color(0xFF9AA4B2);
}

class DebatesApp extends StatelessWidget {
  const DebatesApp({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.accent,
      brightness: Brightness.dark,
    ).copyWith(
      primary: AppColors.accent,
      surface: AppColors.surface,
    );

    return MaterialApp(
      title: appTitle,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: scheme,
        scaffoldBackgroundColor: AppColors.background,
        appBarTheme: const AppBarTheme(
          backgroundColor: AppColors.background,
          elevation: 0,
          centerTitle: false,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
