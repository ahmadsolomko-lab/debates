import '../models.dart';

const List<String> categories = [
  'Гарячі теми',
  'Політика і суспільство',
  'Технології',
  'Легкі теми',
];

const List<Topic> topics = [
  // Гарячі теми
  Topic(
    id: 'same-sex-marriage',
    title: 'Одностатеві шлюби мають бути легальними в усіх країнах ЄС',
    category: 'Гарячі теми',
    hot: true,
  ),
  Topic(
    id: 'euthanasia',
    title: 'Евтаназія має бути легальною для дорослих за їхнім бажанням',
    category: 'Гарячі теми',
    hot: true,
  ),
  Topic(
    id: 'abortion',
    title: 'Аборт має бути легальним на вимогу жінки до 12-го тижня',
    category: 'Гарячі теми',
    hot: true,
  ),
  Topic(
    id: 'guns',
    title: 'Громадяни мають право вільно носити зброю',
    category: 'Гарячі теми',
    hot: true,
  ),
  Topic(
    id: 'gaza',
    title: 'Європейські країни мають визнати державу Палестина',
    category: 'Гарячі теми',
    hot: true,
  ),
  Topic(
    id: 'death-penalty',
    title: 'Смертна кара має бути дозволена за найтяжчі злочини',
    category: 'Гарячі теми',
    hot: true,
  ),

  // Політика і суспільство
  Topic(
    id: 'conscription',
    title: 'Обовʼязкова військова служба має бути в кожній країні ЄС',
    category: 'Політика і суспільство',
  ),
  Topic(
    id: 'ubi',
    title: 'Безумовний базовий дохід — краще рішення, ніж соцдопомога',
    category: 'Політика і суспільство',
  ),
  Topic(
    id: 'four-day-week',
    title: 'Робочий тиждень має бути чотириденним',
    category: 'Політика і суспільство',
  ),
  Topic(
    id: 'voting-16',
    title: 'Голосувати на виборах можна з 16 років',
    category: 'Політика і суспільство',
  ),

  // Технології
  Topic(
    id: 'social-media-16',
    title: 'Соцмережі треба заборонити дітям до 16 років',
    category: 'Технології',
  ),
  Topic(
    id: 'ai-jobs',
    title: 'AI за 20 років забере більшість професій',
    category: 'Технології',
  ),
  Topic(
    id: 'nuclear',
    title: 'Атомна енергетика — найкращий шлях до кліматичних цілей',
    category: 'Технології',
  ),

  // Легкі теми
  Topic(
    id: 'pineapple-pizza',
    title: 'Піца з ананасом — це нормально',
    category: 'Легкі теми',
  ),
  Topic(
    id: 'cats-dogs',
    title: 'Коти кращі за собак',
    category: 'Легкі теми',
  ),
  Topic(
    id: 'remote-school',
    title: 'Школа має бути онлайн хоча б двічі на тиждень',
    category: 'Легкі теми',
  ),
];

List<Topic> topicsIn(String category) =>
    topics.where((t) => t.category == category).toList();
