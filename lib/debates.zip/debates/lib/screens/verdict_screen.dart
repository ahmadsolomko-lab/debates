import 'package:flutter/material.dart';

import '../main.dart';
import '../models.dart';

class VerdictScreen extends StatelessWidget {
  final Topic topic;
  final Side userSide;
  final Verdict verdict;

  const VerdictScreen({
    super.key,
    required this.topic,
    required this.userSide,
    required this.verdict,
  });

  @override
  Widget build(BuildContext context) {
    final String headline;
    final Color headlineColor;
    if (verdict.isDraw) {
      headline = 'Нічия';
      headlineColor = AppColors.accent;
    } else if (verdict.userWins) {
      headline = 'Перемога твоя!';
      headlineColor = AppColors.pro;
    } else {
      headline = 'Переміг AI';
      headlineColor = AppColors.con;
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Вердикт суддів')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: headlineColor.withAlpha(120)),
              ),
              child: Column(
                children: [
                  const Icon(Icons.gavel_rounded,
                      size: 40, color: AppColors.accent),
                  const SizedBox(height: 8),
                  Text(
                    headline,
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.w900,
                      color: headlineColor,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    '${verdict.userTotal} : ${verdict.aiTotal}',
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'ти  ·  AI',
                    style: TextStyle(color: AppColors.textMuted),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    topic.title,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: AppColors.textMuted,
                      height: 1.3,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            for (final score in verdict.scores) ...[
              _JudgeCard(score: score),
              const SizedBox(height: 12),
            ],
            const SizedBox(height: 4),
            const Text(
              'Демо-оцінка: зараз судді рахують прості ознаки тексту. '
              'Справжні AI-судді зʼявляться після підключення сервера.',
              style: TextStyle(color: AppColors.textMuted, fontSize: 12),
            ),
            const SizedBox(height: 20),
            SizedBox(
              height: 52,
              child: FilledButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text(
                  'Нові дебати',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _JudgeCard extends StatelessWidget {
  final JudgeScore score;

  const _JudgeCard({required this.score});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            score.judge,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
          ),
          Text(
            score.criterion,
            style: const TextStyle(color: AppColors.textMuted, fontSize: 12),
          ),
          const SizedBox(height: 12),
          _ScoreBar(label: 'Ти', value: score.user, color: AppColors.pro),
          const SizedBox(height: 8),
          _ScoreBar(label: 'AI', value: score.ai, color: AppColors.con),
          const SizedBox(height: 12),
          Text(score.comment, style: const TextStyle(height: 1.4)),
        ],
      ),
    );
  }
}

class _ScoreBar extends StatelessWidget {
  final String label;
  final int value;
  final Color color;

  const _ScoreBar({
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 28,
          child: Text(
            label,
            style: const TextStyle(color: AppColors.textMuted, fontSize: 12),
          ),
        ),
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(99),
            child: LinearProgressIndicator(
              value: value / 10,
              minHeight: 10,
              color: color,
              backgroundColor: AppColors.surfaceHigh,
            ),
          ),
        ),
        const SizedBox(width: 10),
        SizedBox(
          width: 36,
          child: Text(
            '$value/10',
            textAlign: TextAlign.right,
            style: const TextStyle(fontWeight: FontWeight.w700),
          ),
        ),
      ],
    );
  }
}
