import 'package:flutter/material.dart';

import '../main.dart';
import '../settings.dart';
import 'topics_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void _soon(BuildContext context, String what) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$what зʼявиться в наступній версії')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          appTitle,
          style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 0.5),
        ),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
          children: [
            const Text(
              'Сперечайся будь-якою мовою.\nТри AI-судді вирішать, хто переміг.',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w700,
                height: 1.3,
              ),
            ),
            const SizedBox(height: 20),
            _ModeCard(
              icon: Icons.smart_toy_outlined,
              title: 'Дебати з AI',
              subtitle: '3 раунди проти штучного інтелекту',
              highlighted: true,
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const TopicsScreen()),
              ),
            ),
            const SizedBox(height: 12),
            _ModeCard(
              icon: Icons.hourglass_bottom_rounded,
              title: 'Дебати «3 дні»',
              subtitle: 'З людиною, відповідаєш коли зручно',
              badge: 'Скоро',
              onTap: () => _soon(context, 'Дебати з людьми'),
            ),
            const SizedBox(height: 12),
            _ModeCard(
              icon: Icons.bolt_rounded,
              title: 'Живі дебати',
              subtitle: '5 · 10 · 15 · 30 хвилин',
              badge: 'Версія 2',
              onTap: () => _soon(context, 'Живі дебати'),
            ),
            const SizedBox(height: 28),
            const Text(
              'Мова',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            const _LanguagePanel(),
          ],
        ),
      ),
    );
  }
}

class _ModeCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final String? badge;
  final bool highlighted;
  final VoidCallback onTap;

  const _ModeCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.badge,
    this.highlighted = false,
  });

  @override
  Widget build(BuildContext context) {
    final bg = highlighted ? AppColors.accent : AppColors.surface;
    final fg = highlighted ? Colors.black : Colors.white;
    final sub = highlighted ? Colors.black87 : AppColors.textMuted;

    return Material(
      color: bg,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            children: [
              Icon(icon, size: 32, color: fg),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        color: fg,
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(subtitle, style: TextStyle(color: sub)),
                  ],
                ),
              ),
              if (badge != null)
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppColors.surfaceHigh,
                    borderRadius: BorderRadius.circular(99),
                  ),
                  child: Text(
                    badge!,
                    style: const TextStyle(
                      fontSize: 12,
                      color: AppColors.textMuted,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                )
              else
                Icon(Icons.arrow_forward_rounded, color: fg),
            ],
          ),
        ),
      ),
    );
  }
}

class _LanguagePanel extends StatelessWidget {
  const _LanguagePanel();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        children: [
          Row(
            children: [
              const Expanded(child: Text('Я дебатую мовою')),
              ValueListenableBuilder<String>(
                valueListenable: debateLanguage,
                builder: (context, value, _) => DropdownButton<String>(
                  value: value,
                  underline: const SizedBox.shrink(),
                  borderRadius: BorderRadius.circular(12),
                  items: [
                    for (final lang in debateLanguages)
                      DropdownMenuItem(value: lang, child: Text(lang)),
                  ],
                  onChanged: (v) {
                    if (v != null) debateLanguage.value = v;
                  },
                ),
              ),
            ],
          ),
          const Divider(height: 1),
          ValueListenableBuilder<bool>(
            valueListenable: autoTranslate,
            builder: (context, value, _) => SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('AI-переклад суперника'),
              subtitle: const Text(
                'Суперник пише своєю мовою — ти читаєш своєю',
                style: TextStyle(color: AppColors.textMuted, fontSize: 12),
              ),
              value: value,
              onChanged: (v) => autoTranslate.value = v,
            ),
          ),
        ],
      ),
    );
  }
}
