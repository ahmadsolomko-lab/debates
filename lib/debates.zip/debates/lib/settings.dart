import 'package:flutter/foundation.dart';

/// Мови, якими можна дебатувати. Переклад між ними з'явиться
/// разом зі справжнім AI.
const List<String> debateLanguages = [
  'Українська',
  'Deutsch',
  'English',
  'Español',
];

/// Обрана мова дебатів (поки зберігається лише до закриття застосунку).
final ValueNotifier<String> debateLanguage =
    ValueNotifier<String>(debateLanguages.first);

/// Чи увімкнений автопереклад суперника на мою мову.
final ValueNotifier<bool> autoTranslate = ValueNotifier<bool>(true);

/// Кількість раундів у дебатах з AI.
const int debateRounds = 3;
