import 'dart:math';

import '../models.dart';

/// ДЕМО-РЕЖИМ.
/// Тут немає справжнього штучного інтелекту: суперник відповідає
/// шаблонами, а судді рахують прості ознаки тексту. Цей клас потім
/// замінимо на виклик справжнього AI через наш сервер, а решта
/// застосунку не зміниться.
class DemoAi {
  final Random _random = Random();

  /// Відповідь AI-суперника в заданому раунді.
  Future<String> reply({
    required Topic topic,
    required Side aiSide,
    required int round,
    required String lastUserMessage,
  }) async {
    await Future.delayed(Duration(milliseconds: 900 + _random.nextInt(900)));

    final stance = aiSide == Side.pro ? 'підтримую' : 'не підтримую';
    final quote = _shortQuote(lastUserMessage);

    if (round == 1) {
      return _pick([
        'Я $stance тезу «${topic.title}». Головна причина — наслідки для '
            'звичайних людей: будь-яке рішення тут треба оцінювати за тим, '
            'кому воно реально допоможе, а кому зашкодить. І за цим '
            'критерієм ваша позиція слабша.',
        'Почну з принципу: держава має втручатися лише тоді, коли без '
            'цього страждають інші. Саме тому я $stance тезу «${topic.title}». '
            'Ваш аргумент «$quote» звучить переконливо, але він описує '
            'окремий випадок, а не правило.',
      ]);
    }

    if (round == 2) {
      return _pick([
        'Ви кажете: «$quote». Але це твердження без доказів. Які дані '
            'показують, що так буде на практиці? Без цифр це лише думка, '
            'а не аргумент.',
        'Зверніть увагу: «$quote» — це наслідок, а не причина. Якщо '
            'прибрати емоції, то залишається питання ціни: хто за це '
            'платить і чи готове суспільство до цього?',
      ]);
    }

    return _pick([
      'Підсумую. Протягом дебатів ви не відповіли на головне питання — '
          'як ваша позиція працює в реальному житті, а не в теорії. Тому я '
          'й надалі $stance тезу «${topic.title}».',
      'На завершення: сильні емоції не замінюють сильних доказів. '
          'Моя позиція спирається на принцип і наслідки, і саме тому вона '
          'стійкіша за вашу.',
    ]);
  }

  /// Оцінка трьох суддів.
  Verdict judge(List<DebateMessage> messages) {
    final userText = messages
        .where((m) => m.speaker == Speaker.user)
        .map((m) => m.text)
        .join(' ');
    final aiText = messages
        .where((m) => m.speaker == Speaker.ai)
        .map((m) => m.text)
        .join(' ');

    final userLogic = _logic(userText);
    final aiLogic = _logic(aiText);
    final userEvidence = _evidence(userText);
    final aiEvidence = _evidence(aiText);
    final userRhetoric = _rhetoric(userText);
    final aiRhetoric = _rhetoric(aiText);

    return Verdict([
      JudgeScore(
        judge: 'Суддя логіки',
        criterion: 'Логіка',
        user: userLogic,
        ai: aiLogic,
        comment: userLogic >= 7
            ? 'Аргументи повʼязані між собою, видно причину і наслідок.'
            : 'Додай звʼязки: «тому що», «отже», «якщо… то». Зараз '
                'думки стоять окремо одна від одної.',
      ),
      JudgeScore(
        judge: 'Суддя обґрунтованості',
        criterion: 'Факти й докази',
        user: userEvidence,
        ai: aiEvidence,
        comment: userEvidence >= 7
            ? 'Є цифри та приклади — це посилює позицію.'
            : 'Бракує конкретики: цифр, прикладів, досліджень. '
                'Без них аргумент — лише думка.',
      ),
      JudgeScore(
        judge: 'Суддя риторики',
        criterion: 'Риторика',
        user: userRhetoric,
        ai: aiRhetoric,
        comment: userRhetoric >= 7
            ? 'Яскраво, різноманітно і зрозуміло.'
            : 'Пиши різноманітніше: менше повторів, більше чітких '
                'коротких речень і риторичних запитань.',
      ),
    ]);
  }

  // ---------- прості ознаки тексту (лише для демо) ----------

  static const _logicWords = [
    'тому що', 'оскільки', 'отже', 'тому', 'бо ', 'якщо', 'то ', 'адже',
    'через це', 'по-перше', 'по-друге', 'наслідок', 'причина',
    'because', 'therefore', 'if ', 'weil', 'deshalb', 'wenn', 'porque',
  ];

  static const _evidenceWords = [
    'дослідж', 'дані', 'статистик', 'наприклад', 'джерел', 'відсот',
    'згідно', 'приклад', 'study', 'data', 'example', 'studie', 'beispiel',
    'ejemplo',
  ];

  int _logic(String text) {
    final t = text.toLowerCase();
    var hits = 0;
    for (final w in _logicWords) {
      hits += _count(t, w);
    }
    final words = _words(t).length;
    final score = 3 + hits * 1.2 + min(words / 40, 2.5);
    return _clamp(score.round());
  }

  int _evidence(String text) {
    final t = text.toLowerCase();
    var hits = RegExp(r'\d').hasMatch(t) ? 2 : 0;
    hits += _count(t, '%');
    for (final w in _evidenceWords) {
      hits += _count(t, w);
    }
    final score = 2 + hits * 1.3;
    return _clamp(score.round());
  }

  int _rhetoric(String text) {
    final words = _words(text.toLowerCase());
    if (words.isEmpty) return 1;
    final variety = words.toSet().length / words.length; // 0..1
    final questions = _count(text, '?');
    final lengthBonus = min(words.length / 60, 2.0);
    final score = 2 + variety * 5 + min(questions, 2) + lengthBonus;
    return _clamp(score.round());
  }

  int _clamp(int v) => max(1, min(10, v));

  List<String> _words(String text) => text
      .split(RegExp(r'[\s,.!?;:«»"()—-]+'))
      .where((w) => w.isNotEmpty)
      .toList();

  int _count(String text, String pattern) {
    var count = 0;
    var index = text.indexOf(pattern);
    while (index != -1) {
      count++;
      index = text.indexOf(pattern, index + pattern.length);
    }
    return count;
  }

  String _shortQuote(String text) {
    final clean = text.trim().replaceAll(RegExp(r'\s+'), ' ');
    if (clean.isEmpty) return '…';
    final words = clean.split(' ');
    if (words.length <= 8) return clean;
    return '${words.take(8).join(' ')}…';
  }

  String _pick(List<String> options) =>
      options[_random.nextInt(options.length)];
}
