enum Side { pro, con }

enum Speaker { user, ai }

extension SideLabel on Side {
  String get label => this == Side.pro ? 'ЗА' : 'ПРОТИ';
  Side get opposite => this == Side.pro ? Side.con : Side.pro;
}

class Topic {
  final String id;
  final String title;
  final String category;
  final bool hot;

  const Topic({
    required this.id,
    required this.title,
    required this.category,
    this.hot = false,
  });
}

class DebateMessage {
  final Speaker speaker;
  final String text;
  final int round;

  const DebateMessage({
    required this.speaker,
    required this.text,
    required this.round,
  });
}

class JudgeScore {
  final String judge;
  final String criterion;
  final int user;
  final int ai;
  final String comment;

  const JudgeScore({
    required this.judge,
    required this.criterion,
    required this.user,
    required this.ai,
    required this.comment,
  });
}

class Verdict {
  final List<JudgeScore> scores;

  const Verdict(this.scores);

  int get userTotal => scores.fold(0, (sum, s) => sum + s.user);
  int get aiTotal => scores.fold(0, (sum, s) => sum + s.ai);
  bool get isDraw => userTotal == aiTotal;
  bool get userWins => userTotal > aiTotal;
}
